import java.sql.*;
import java.time.*;
import java.util.*;
import javafx.scene.chart.*;

/**
 * DataBaseSpese: classe che realizza il back-end e tutte le operazioni da effettuare sulla base di dati.
 */
public class DataBaseSpese {

    private static Connection connessioneADatabase;
    private static PreparedStatement statementGetSpeseInserite;
    private static PreparedStatement statementGetCategorie;
    private static PreparedStatement statementGetStorico;
    private static PreparedStatement statementAggiungiSpesa;
    private static PreparedStatement statementEliminaSpesa;
    private static String url;
    private static String usernameDatabase;
    private static String passwordDatabase;

    
    public DataBaseSpese (ParametriConfigurazione p) {
        String indirizzoIP = p.getParametriDatabase().getIndirizzoIpDb();
        int porta = p.getParametriDatabase().getPortaDb();
        String nomeDB = p.getParametriDatabase().getNomeDb();
        usernameDatabase = p.getParametriDatabase().getUsernameDb();
        passwordDatabase = p.getParametriDatabase().getPwdDb();
        url = "jdbc:mysql://"+indirizzoIP+":"+porta+"/"+nomeDB;
        String numRow = String.valueOf(p.getParametriStilistici().getMaxRecord());
        
        try { //(1)
            connessioneADatabase = DriverManager.getConnection(url, usernameDatabase, passwordDatabase);
            statementGetSpeseInserite = connessioneADatabase.prepareStatement("SELECT * FROM spesa ORDER BY data DESC LIMIT "+numRow);
            statementGetCategorie = connessioneADatabase.prepareStatement("SELECT nome FROM categoria ORDER BY nome");
            statementGetStorico = connessioneADatabase.prepareStatement("SELECT SUM(costo) as costo, categoria FROM spesa WHERE data>=? AND data<=? GROUP BY categoria");     
            statementAggiungiSpesa = connessioneADatabase.prepareStatement("INSERT INTO spesa VALUES (?,?,?,?,?)");
            statementEliminaSpesa = connessioneADatabase.prepareStatement("DELETE FROM spesa WHERE idSpesa = ?");
        } catch(SQLException e) {
            System.err.println(e.getMessage());            
        }
     
    }

    public List<Spesa> ottieniListaSpese() { //(2)
        List<Spesa> listaSpese = new ArrayList<>();
        try(ResultSet rs = statementGetSpeseInserite.executeQuery();) {
            while(rs.next())
                listaSpese.add(new Spesa(rs.getInt("idSpesa"), rs.getDouble("costo"), rs.getString("categoria"), rs.getString("descrizione"), rs.getDate("data").toString()));
        } catch(SQLException e ) {
            System.err.println(e.getMessage()); 
        }
        return listaSpese;
    }
    
    public List<String> ottieniCategorie() { //(3)
        List<String> listaCategorie = new ArrayList<>();
        try(ResultSet rs = statementGetCategorie.executeQuery();) {
            while(rs.next())
                listaCategorie.add(rs.getString("nome"));
        } catch(SQLException e ) {
            System.err.println(e.getMessage()); 
        }
        return listaCategorie;
    }
    
    public List<PieChart.Data> ottieniStoricoSpese(LocalDate dataInizio, LocalDate dataFine) { //(4)
        List<PieChart.Data> listaStorico = new ArrayList<>();
        try {
            statementGetStorico.setDate(1, java.sql.Date.valueOf(dataInizio));
            statementGetStorico.setDate(2, java.sql.Date.valueOf(dataFine));
            ResultSet rs = statementGetStorico.executeQuery();
            
            while(rs.next())
                listaStorico.add(new PieChart.Data(rs.getString("categoria"), rs.getDouble("costo")));
            
        } catch(SQLException e) {
            e.printStackTrace();
        }
        return listaStorico;
    }
    
    public void aggiungiSpesa(double costo, String categoria, String descrizione, LocalDate data) { //(5)
        try{
            statementAggiungiSpesa.setInt(1, 0);
            statementAggiungiSpesa.setDouble(2, costo);
            statementAggiungiSpesa.setString(3, categoria);
            statementAggiungiSpesa.setString(4, descrizione);
            statementAggiungiSpesa.setDate(5, java.sql.Date.valueOf(data)); 

            statementAggiungiSpesa.executeUpdate();
            System.out.println("Spesa salvata.");

        } catch(SQLException e) {
            System.err.println(e.getMessage());
        }        
    }
    
    public void eliminaSpesa(int idSpesa) { //(6)
        try{
            statementEliminaSpesa.setInt(1, idSpesa);
            statementEliminaSpesa.executeUpdate();
            System.out.println("Spesa eliminata.");
        } catch(SQLException e) {
            System.err.println(e.getMessage());
        }
    }
      
}
/*Note
1)Si settano tutte le query da utilizzare. Si utilizza inoltre anche il parametro di configurazione del numero massimo
di record da estrarre dalla base di dati.

2)Metodo che restituisce la lista delle spese archiviate nel database ed utilizzate dalla TableView della classe TabellaUltimeSpese.

3)Metodo che restituisce la lista delle categorie archiviate nel database ed utilizzade dal comboBox della classe NuovaSpesa.

4)Restituisce la lista di dati utili a popolare il diagramma, cioè le spese raggruppate per categoria.

5)Archivia la spesa inserita nel form della classe NuovaSpesa.

6)Elimina la spesa seleziona dalla tabella della classe TabellaUltimeSpese
*/