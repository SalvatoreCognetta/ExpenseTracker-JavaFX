import java.time.*;
import javafx.collections.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.event.*;
import javafx.geometry.*;

/**
 * NuovaSpesa: classe contenente il form per l'inserimento di una nuova spesa.
 *
 */
public class NuovaSpesa {
    
    private DataBaseSpese dataBase; //(1)
    private LogXMLAttivita socketDiLog; //(2)
    private CacheSpesaNonSalvata cache; //(3)
    private ParametriConfigurazione parametriConfig; //(4)
    private TabellaUltimeSpese tb; //(5)
    private VBox vboxprincipale;
    private HBox hboxInserimento;
    private HBox hboxBtn;
    private Label titolo;
    private TextField costoSpesa;
    private ComboBox categoriaSpesa;
    private ObservableList<String> opzioniComboBox;
    private TextField descrizioneSpesa;
    private DatePicker dataSpesa;
    private Button btnAnnulla;
    private Button btnSalva;
    
    public NuovaSpesa(DataBaseSpese db, LogXMLAttivita so, TabellaUltimeSpese tb, CacheSpesaNonSalvata cache, ParametriConfigurazione param) {
        this.dataBase = db;
        this.socketDiLog = so;
        this.tb = tb;
        this.cache = cache;
        this.parametriConfig = param;
        String[] spesa = cache.prelevaSpesaNonSalvata();
        titolo = new Label("Inserisci una nuova spesa");
        costoSpesa = new TextField();
        costoSpesa.setPromptText("0.00€");
        if(spesa[0] != null)
            costoSpesa.setText(spesa[0]);
        
        opzioniComboBox = FXCollections.observableArrayList();
        opzioniComboBox.addAll(db.ottieniCategorie());
        categoriaSpesa = new ComboBox(opzioniComboBox);
        categoriaSpesa.setPromptText("Categoria");
        if(spesa[1] != null)
            categoriaSpesa.setValue(spesa[1]);
        descrizioneSpesa = new TextField();
        descrizioneSpesa.setPromptText("Descrizione");
        if(spesa[2] != null)
            descrizioneSpesa.setText(spesa[2]);
        dataSpesa = new DatePicker();
        if(spesa[3] == null)
            dataSpesa.setPromptText(LocalDate.now().toString());
        else
            dataSpesa.setValue(LocalDate.parse(spesa[3]));
        hboxInserimento = new HBox();
        hboxInserimento.getChildren().addAll(costoSpesa, categoriaSpesa, descrizioneSpesa, dataSpesa);
        btnAnnulla = new Button("Annulla");
        btnAnnulla.setOnAction((ActionEvent ev) -> {annullaInserimento(); socketDiLog.inviaMessaggioLogEvento(TipoLog.CLICK_PULSANTE_ANNULLA);});//(6)
        
        btnSalva = new Button("Salva");
        btnSalva.setOnAction((ActionEvent ev) -> {salvaSpesa(); socketDiLog.inviaMessaggioLogEvento(TipoLog.CLICK_PULSANTE_SALVA);});//(7)
        
        hboxBtn = new HBox();
        hboxBtn.getChildren().addAll(btnAnnulla, btnSalva);
        vboxprincipale = new VBox();
        vboxprincipale.getChildren().addAll(titolo, hboxInserimento, hboxBtn);
        setStyle();
    }
    
    private void annullaInserimento() { //(8)
        costoSpesa.setText("");
        categoriaSpesa.setValue(null);
        descrizioneSpesa.setText("");
        dataSpesa.setValue(null);
        System.out.println("Campi puliti.");
    }
    
    private void salvaSpesa() { //(9)
        double costo;
        String categoria;
        LocalDate data;
        
        if(!costoSpesa.getText().isEmpty())
            costo = Double.parseDouble(costoSpesa.getText());
        else {
            System.out.println("Impossibile salvare la spesa, manca il parametro costo.");
            return;
        }
        
        if(categoriaSpesa.getValue() != null)
            categoria = categoriaSpesa.getValue().toString();
        else {
            System.out.println("Impossibile salvare la spesa, manca il parametro categoria.");
            return;
        }
        
        String descrizione = descrizioneSpesa.getText();
        
        if(dataSpesa.getValue() != null)
            data = dataSpesa.getValue();
        else
            data = LocalDate.now();
        
        dataBase.aggiungiSpesa(costo, categoria, descrizione, data);
        tb.caricaSpese();
        annullaInserimento();
    }
    
    public VBox getVBox() { //(10)
        return vboxprincipale;
    }
    
    public String[] getSpesa() { //(11)
        String[] l = new String[]{ 
            costoSpesa.getText(),
            categoriaSpesa.getValue() == null ? null : categoriaSpesa.getValue().toString(),
            descrizioneSpesa.getText(),
            dataSpesa.getValue()== null ? null : dataSpesa.getValue().toString()
        };
        return l;
    }
    
    private void setStyle() { //(12)
        String font = parametriConfig.getParametriStilistici().getFont();
        String dimensione = String.valueOf(parametriConfig.getParametriStilistici().getDimensioneFont().getDimensione());
        String unita = parametriConfig.getParametriStilistici().getDimensioneFont().getUnita();
        titolo.setStyle("-fx-font-family: " + font + "; -fx-font-size: " + dimensione + unita);
        hboxInserimento.setStyle("-fx-border-width: 2px; -fx-border-color: #5592f4; -fx-spacing:10; -fx-border-radius: 5px; ");
        hboxInserimento.setMinSize(50, 55);
        btnAnnulla.setStyle("-fx-color: #d13e3e");
        btnSalva.setStyle("-fx-color: #3a6cb7");
        hboxBtn.setAlignment(Pos.CENTER);
        hboxBtn.setSpacing(10);
        hboxInserimento.setAlignment(Pos.CENTER);
        vboxprincipale.setStyle("-fx-spacing:10;");

    }
    
}
/*Note
1)La classe DataBaseSpese è utilizzata per effettuare le operazioni sul database, cioè il caricamento nella base di dati di una nuova
spesa effettuata.

2)La classe LogXMLAttivita è utilizzata per inviare righe di log nel caso l'utente clicchi sul button annulla(6) oppure salva(7).

3)La cache viene utilizzata quando l'utente chiude l'applicativo prima di salvare la spesa inserita.
Nel caso sia stato inserita la spesa ma non salvata, all'avvio successivo viene impostata nei campi del form.

4)I parametri di configurazione vengono utilizzati per settare lo stile, quindi viene utilizzata la classe ParametriStilistici, con i suoi metodi get,
che restituiscono font, dimensione ed unità.

5)La classe TabellaUltimeSpese serve per aggiornare la tabella nel caso di inserimento di una nuova spesa.

8)Ripulisce i campi del form nel caso si prema annulla.

9)Viene richiamata il metodo aggiungiSpesa del DataBaseSpese per il salvataggio nella base di dati della spesa inserita (quando viene 
premuto il button salva).

10)Metodo che ritorna il vbox contentente la tabella, il titolo ed il button. Viene utilizzata dal metodo start per aggiungerla alla scena.

11)Restituisce la spesa inserita sotto forma di array di stringhe. Il metodo è utilizzato dalla cache per il salvataggio su file binario.

12)Metodo che setta lo stile di tutti gli elementi della classe, utilizzando i parametri stilistici di configurazione.
*/