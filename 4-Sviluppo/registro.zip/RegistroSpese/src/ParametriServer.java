
import java.io.*;
/**
 * ParametriServer: parametri di configurazione per la connessione con il server
 * di log.
 * 
 */

public class ParametriServer {//non implementa Serializable poichè la serializzazione vienne effettuata da XStream e non sull'oggetto java
    
    private String indirizzoIPServerDiLog;
    private int portaServerDiLog;
    
    public ParametriServer(String ind, int porta) {
        this.indirizzoIPServerDiLog = ind;
        this.portaServerDiLog = porta;
    }
    
    public String getIndirizzoIpSrvr() {
        return indirizzoIPServerDiLog;
    }
    
    public int getPortaServer() {
        return portaServerDiLog;
    }
    
}
