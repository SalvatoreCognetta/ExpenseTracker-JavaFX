/**
* Enumerato di tutti i possibili eventi che scaturiscono un invio di un messaggio di log.
*/
public enum TipoLog {
    AVVIO_APPLICAZIONE,
    CLICK_PULSANTE_SALVA,
    CLICK_PULSANTE_ANNULLA,
    CLICK_PULSANTE_ELIMINA,
    CLICK_TABELLA_ULTIME_SPESE,
    CLICK_PULSANTE_AGGIORNA,
    TERMINE_APPLICAZIONE
}
