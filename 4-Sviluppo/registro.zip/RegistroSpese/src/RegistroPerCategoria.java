import java.time.*;
import java.util.*;
import javafx.collections.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.chart.*;
import javafx.event.*;
import javafx.geometry.*;

/**
* RegistroPerCategoria: classe che mostra il diagramma delle spese raggruppate per categoria
* in un range limitato di date.
*/
        
public class RegistroPerCategoria {
    
    private DataBaseSpese database; //(1)
    private LogXMLAttivita socketDiLog; //(2)
    private ParametriConfigurazione parametriConfig; //(3)
    private VBox vboxPrincipale;
    private HBox hboxGrafico;
    private VBox vboxData;
    private Label titolo;
    private PieChart diagramma;
    private ObservableList<PieChart.Data> datiDiagramma;
    private Label lblPeriodo;
    private Label lblDataInizio;
    private DatePicker dataInizio;
    private Label lblDataFine;
    private DatePicker dataFine;
    private Button aggiorna;
    
    public RegistroPerCategoria(DataBaseSpese db, LogXMLAttivita so, ParametriConfigurazione param) {
        this.database = db;
        this.socketDiLog = so;
        this.parametriConfig = param;
        
        vboxPrincipale = new VBox();
        
        titolo = new Label("Registro per categoria");
        
        hboxGrafico = new HBox();
        datiDiagramma = FXCollections.observableArrayList();
        
        diagramma = new PieChart(datiDiagramma);
               
        vboxData = new VBox();
        
        lblPeriodo = new Label("Seleziona periodo da considerare");
        
        lblDataInizio = new Label("Data Inizio:");
        dataInizio = new DatePicker();
        dataInizio.setValue(LocalDate.now());
        
        lblDataFine = new Label("Data Fine:");
        dataFine = new DatePicker();
        dataFine.setValue(LocalDate.now());
        
        aggiorna = new Button("Aggiorna");
        aggiorna.setOnAction((ActionEvent ev) -> {aggiornaGrafico(); socketDiLog.inviaMessaggioLogEvento(TipoLog.CLICK_PULSANTE_AGGIORNA);}); //(4)
        
        vboxData.getChildren().addAll(lblPeriodo,lblDataInizio, dataInizio, lblDataFine, dataFine, aggiorna);

        hboxGrafico.getChildren().addAll(diagramma, vboxData);

        vboxPrincipale.getChildren().addAll(titolo, hboxGrafico);
        
        setStyle();
    }
    
    public void aggiornaGrafico() { //(5)
        List<PieChart.Data> d = database.ottieniStoricoSpese(dataInizio.getValue(), dataFine.getValue());
        if (d.isEmpty()) 
            d.add(new PieChart.Data("Nessun valore", 1));
        datiDiagramma.clear();
        datiDiagramma.addAll(d);
    }
    
    
    public VBox getVbox() { //(6)
        return vboxPrincipale;
    }
    
    private void setStyle() { //(7)
        String font = parametriConfig.getParametriStilistici().getFont();
        String dimensione = String.valueOf(parametriConfig.getParametriStilistici().getDimensioneFont().getDimensione());
        String unita = parametriConfig.getParametriStilistici().getDimensioneFont().getUnita();
        titolo.setStyle("-fx-font-family: " + font + "; -fx-font-size: " + dimensione + unita);
        hboxGrafico.setStyle("-fx-border-width: 2px; -fx-border-color:grey;");
        vboxData.setStyle("-fx-spacing:10");
        vboxData.setAlignment(Pos.CENTER);
        vboxPrincipale.setSpacing(10);
    }
}

/*Note
1)La classe DataBaseSpese è utilizzata per caricare i dati nel diagramma delle spese, raggruppate per categoria, in un range di date.

2)La classe LogXMLAttivita è utilizzata per inviare righe di log nel caso l'utente clicchi sul button aggiorna (4).

3)I parametri di configurazione vengono utilizzati per settare lo stile, quindi viene utilizzata la classe ParametriStilistici, con i suoi metodi get,
che restituiscono font, dimensione ed unità. 

5)Aggiorna il diagramma con i dati ottenuti dal database. Se non ci sono spese effettuate nel periodo di riferimento, 
il diagramma mostra "nessun valore".

6)Metodo che ritorna il vbox contentente il diagramma, il titolo, i due datepicker (con relative label) il button.
Viene utilizzata dal metodo start per aggiungerla alla scena.

7)Metodo che setta lo stile di tutti gli elementi della classe, utilizzando i parametri stilistici di configurazione.

*/