import java.util.*;
import javafx.collections.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.control.cell.*;
import javafx.event.*;
import javafx.geometry.*;


/**
 * TabellaUltimeSpese: classe contenente la tabella delle ultime spese e la possibilità di eliminazione di 
 * una di esse tramite un button 'Elimina'.
 */

public class TabellaUltimeSpese {

    private DataBaseSpese dataBase; //(1)
    private LogXMLAttivita socketDiLog; //(2)
    private ParametriConfigurazione parametriConfig; //(3)
    private VBox vbox;
    private Label titolo;
    private TableView<Spesa> table;
    private ObservableList<Spesa> listaSpese;
    private Button btnEliminaSpesa;

    public TabellaUltimeSpese (DataBaseSpese db, LogXMLAttivita so, ParametriConfigurazione param) {
        this.dataBase = db;
        this.socketDiLog = so;
        this.parametriConfig = param;
        
        titolo = new Label("UltimeSpese");
        table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        
        TableColumn descrizioneCol = new TableColumn("Descrizione Spesa");
        descrizioneCol.setCellValueFactory(new PropertyValueFactory<>("descrizione"));
        
        TableColumn categoriaCol = new TableColumn("Categoria");
        categoriaCol.setCellValueFactory(new PropertyValueFactory<>("categoria"));
        
        TableColumn costoCol = new TableColumn("Costo");
        costoCol.setCellValueFactory(new PropertyValueFactory<>("costo"));
        
        TableColumn dataCol = new TableColumn("Data");
        dataCol.setCellValueFactory(new PropertyValueFactory<>("data"));
        
        listaSpese = FXCollections.observableArrayList();

        table.setItems(listaSpese);
        table.getColumns().addAll(descrizioneCol, categoriaCol, costoCol, dataCol);
        table.setOnMouseClicked((event) -> {socketDiLog.inviaMessaggioLogEvento(TipoLog.CLICK_TABELLA_ULTIME_SPESE);}); //(4)
        
        btnEliminaSpesa = new Button("Elimina");
        btnEliminaSpesa.setOnAction((ActionEvent ev) -> {eliminaSpesa(); socketDiLog.inviaMessaggioLogEvento(TipoLog.CLICK_PULSANTE_ELIMINA);});//(5)
        
        vbox = new VBox();
        vbox.getChildren().addAll(titolo, table, btnEliminaSpesa);
        setStyle();
    }

    public void caricaSpese() { //(6)
        List<Spesa> spese = dataBase.ottieniListaSpese();
        listaSpese.clear();
        listaSpese.addAll(spese);
    }
    
    private void eliminaSpesa() { //(7)
        Spesa tmp = table.getSelectionModel().getSelectedItem();
        if (tmp == null)
            System.out.println("Nessuna spesa selezionata.");
        else {
            System.out.println("Eliminata la spesa nr°: " + tmp.getId());
            dataBase.eliminaSpesa(tmp.getId());
        }
        
        caricaSpese();  
    }
    
    public VBox getVBox() { //(8)
        return vbox;
    }
    
    private void setStyle() { //(9)
        String font = parametriConfig.getParametriStilistici().getFont();
        String dimensione = String.valueOf(parametriConfig.getParametriStilistici().getDimensioneFont().getDimensione());
        String unita = parametriConfig.getParametriStilistici().getDimensioneFont().getUnita();
        titolo.setStyle("-fx-font-family: " + font + "; -fx-font-size: " + dimensione + unita);
        vbox.setSpacing(10);
        table.setMinHeight(150);
        table.setMaxHeight(150);
        btnEliminaSpesa.setStyle("-fx-color: #d13e3e");
        vbox.setAlignment(Pos.CENTER);

    }
}

/*Note
1)La classe DataBaseSpese è utilizzata per effettuare le operazioni sul database, cioè il caricamento nell'ObservableList listaSpese,
e l'eliminazione di una spesa effettuata.

2)La classe LogXMLAttivita è utilizzata per inviare righe di log nel caso l'utente clicchi sulla tabella (4) oppure sul button elimina (5).

3)I parametri di configurazione vengono utilizzati per settare lo stile, quindi viene utilizzata la classe ParametriStilistici, con i suoi metodi get,
che restituiscono font, dimensione ed unità.

6)Il metodo caricaSpese ha lo scopo di richiedere al database la lista di spese archiviate, e di aggiungerle alla listaSpese(lista Osservabile).

7)Il metodo eliminaSpese ha lo scopo di elimare dal databe la spesa selezionata dall'utente. Se l'utente ha premuto per sbaglio il button elimina
viene stampato a video una stringa.

8)Metodo che ritorna il vbox contentente la tabella, il titolo ed il button. Viene utilizzata dal metodo start per aggiungerla alla scena.

9)Metodo che setta lo stile di tutti gli elementi della classe, utilizzando i parametri stilistici di configurazione.
*/