import java.io.*;
/**
 * ParametriConfigurazione: classe principale dei parametri di configurazione, 
 * contenente tutti i parametri: server, database e stilistici.
 */
public class ParametriConfigurazione implements Serializable {
    
    private ParametriServer parametriServer; //(1)
    private ParametriDataBase parametriDatabase; //(2)
    private ParametriStilistici parametriStilistici;    
    
    public ParametriConfigurazione(ParametriServer paramSrvr, ParametriDataBase paramDb, ParametriStilistici stilistici) {
        this.parametriServer = paramSrvr;
        this.parametriDatabase = paramDb;
        this.parametriStilistici = stilistici;
    }
    
    public ParametriServer getParametriServer() {
        return parametriServer;
    }
    
    public ParametriDataBase getParametriDatabase() {
        return parametriDatabase;
    }
    
    public ParametriStilistici getParametriStilistici() {
        return parametriStilistici;
    }
}
/*Note
1)I parametri server servono alla classe LogXMLAttivita, per connettersi al server ed inviare righe di log.

2)I parametri database vengono utilizzati dalla classe DatabaseSpese, per la connessione con il database ed il prelievo/salvataggio di record.

3)I parametri stilistici vengono utilizzati dalle tre classi NuovaSpesa, TabellaUltimeSpese e RegistroPerCategoria per settare lo stile. 
Inoltre vengono utilizzati anche da DataBaseSpese, per il numero massimo di record da estrarre dal database.
*/